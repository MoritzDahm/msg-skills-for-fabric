# MSG Power BI Standards

## Purpose

Apply MSG corporate design standards and dashboard best practices to every report.

## Corporate Colors

Primary Color:
#A01441

Secondary Color:
#56A3BC

Neutral Color:
#6F6F6F

Background:
#FFFFFF

## Fonts

Always use:

- Aptos
- Segoe UI (fallback)

Never use decorative fonts.

## Theme Selection

Use:

msg-theme-executive.json

for:

- Management Dashboards
- Executive Dashboards
- Steering Reports
- Board Reports

Use:

msg-theme-operational.json

for:

- Operational Reporting
- Service Dashboards
- Support Reports
- Detailed Monitoring Reports

## Layout Rules

Keep layouts simple and uncluttered.

Preferred structure:

Top Row:
- KPI Cards

Middle Row:
- Trend Analysis

Bottom Row:
- Detailed Breakdown

Maximum:
- 6 major visuals per page

Preferred:
- White background
- Large whitespace
- Clear hierarchy

Avoid:
- Dense layouts
- Decorative elements
- Visual overload

## Layout Rules

Keep layouts simple and uncluttered.

Preferred structure:

Top Row:
- KPI Cards

Middle Row:
- Trend Analysis

Bottom Row:
- Detailed Breakdown

Maximum:
- 6 major visuals per page

Preferred:
- White background
- Large whitespace
- Clear hierarchy

Avoid:
- Dense layouts
- Decorative elements
- Visual overload

## KPI Rules

Important KPI:
MSG Red (#A01441)

Supporting KPI:
MSG Petrol (#56A3BC)

Neutral Information:
MSG Gray (#6F6F6F)

Use color sparingly.

Color must never be the only indicator.

## PBIP Rules

Always create reports in PBIP format.

Always generate:

- report.json
- pages
- bookmarks
- theme reference

Use corporate theme automatically.

Every report must comply with MSG standards.